package com.jy.board.movie;

import com.jy.board.main.DBManager;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import javax.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MovieDAO {
    // 전체조회 기능

    public static void selectAllMovie(HttpServletRequest req){
        // 값 or DB

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from MOVIE_TEST";
        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();
            MovieDTO dto = null;
            ArrayList<MovieDTO> movies = new ArrayList<>();
            while (rs.next()) {
                dto = new MovieDTO();
                dto.setNo(rs.getInt("m_no"));
                dto.setTitle(rs.getString("m_title"));
                dto.setActor(rs.getString("m_actor"));
                dto.setImg(rs.getString("m_img"));
                dto.setStory(rs.getString("m_story"));
                movies.add(dto);
            }
            req.setAttribute("movies", movies);
            System.out.println(movies);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con,pstmt,rs);
        }

    }

    public static void addMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "insert into movie_test values (movie_test_seq.nextval, ?, ?, ?,?)";
        String path = request.getServletContext().getRealPath("movieFile");

        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);

            // 박스포장해놓은것때문에 바로 request로 사용 불가능 => ↓ multipartrequest사용
            MultipartRequest mr = new MultipartRequest(request,path,
                    1024*1024*20, "UTF-8", new DefaultFileRenamePolicy());

            // 값받기 시작
            String title = mr.getParameter("title");

            String actor = mr.getParameter("actor");
            String story = mr.getParameter("story");
            String fileName = mr.getFilesystemName("img");

            System.out.println(title);
            System.out.println(actor);
            System.out.println(story);
            System.out.println(fileName);

            story = story.replaceAll("\r\n", "<br>");

            pstmt.setString(1, title);
            pstmt.setString(2, actor);
            pstmt.setString(3, fileName);
            pstmt.setString(4, story);

            if(pstmt.executeUpdate() == 1){
                System.out.println("add success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con,pstmt,null);
        }
    }

    public static void deleteMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "delete from movie_test where M_NO = ?";

        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("no")); //index에서 받는 parameter값의 name?

            if(pstmt.executeUpdate() == 1){
                System.out.println("delete success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con,pstmt,null);
        }
    }


    public static void upMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "update movie_test set M_TITLE=? where M_NO = ?";

        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("title")); //index에서 받는 parameter값의 name?
            pstmt.setString(2, request.getParameter("no"));
            if(pstmt.executeUpdate() == 1){
                System.out.println("update success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con,pstmt,null);
        }
    }

    public static void getMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from MOVIE_TEST where M_NO = ?";
        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("no")); // "no" <= movie.jsp url들어가는 parameter값
            rs = pstmt.executeQuery();
            MovieDTO dto = null;
            if (rs.next()) {
                dto = new MovieDTO();
                dto.setNo(rs.getInt("m_no"));
                dto.setTitle(rs.getString("m_title"));
                dto.setActor(rs.getString("m_actor"));
                dto.setImg(rs.getString("m_img"));
                dto.setStory(rs.getString("m_story"));
            }
            System.out.println(dto);
            request.setAttribute("movie", dto);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con,pstmt,rs);
        }
    }
}


