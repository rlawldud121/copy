package com.jy.board.review;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/review")
public class ReviewC extends HttpServlet {


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    request.setAttribute("content", "jsp/review/review.jsp");
    request.getRequestDispatcher("index.jsp").forward(request,response);

    }



    public void destroy() {
    }
}