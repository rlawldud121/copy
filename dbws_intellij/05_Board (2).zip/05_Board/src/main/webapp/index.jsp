<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP - Hello World</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/movie.css">
</head>
<body>
<div class="container">
    <div class="title">
        <a href="main"> ♥Ziyoung's place♥ </a>
    </div>
    <div class="menu">
        <div>
            <a href="menu1">[Menu1]</a>
        </div>
        <div>
            <a href="movie">[Movie]</a>
        </div>
        <div>
            <a href="review">[Review]</a>
        </div>
    </div>
    <div class="content">
        <jsp:include page="${content }"></jsp:include>
    </div>
</div>
</body>
</html>