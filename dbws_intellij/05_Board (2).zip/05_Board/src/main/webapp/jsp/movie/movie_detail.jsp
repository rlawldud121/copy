
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<h1>- Movie Deatil -</h1>
<div style="display: flex; justify-content: center;">
    <div class="movie-detail">
        <div>
            <div class="col-1">No.</div>
            <div class="col-2"></div>
        </div>
        <div>
            <div><img src="${movie.img}"></div>
        </div>
        <div>
            <div class="col-1">Title.</div>
            <div class="col-2">${movie.title}</div>

        </div>
        <div>
            <div class="col-1">Actor.</div>
            <div class="col-2">${movie.actor}</div>
        </div>

        <div>
            <div class="col-1">Story.</div>
            <div class="col-2">${movie.story}</div>
        </div>


    </div>
</div>

</body>
</html>
